<script type="text/javascript">
	var app = angular.module('firstApp', []);
	angular.module('', [])
</script>