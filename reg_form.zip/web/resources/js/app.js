
var app = angular.module('signupLoginApp', []);
	app.controller('signUpController', function($scope, $http){
		 $scope.siteURL = '<?php echo base_url()?>';//'<?php echo base_url()?>';
		 $scope.registration = {
		 	fullName: '',
		 	email: '',
		 	password: '',
		 	country: '',
		 	gender: '',
		 	town: '',
		 	refEmail: ''
		 }
		 $scope.registerSuccess = "";
		 $scope.registerFailed = "";
		$scope.submitRegisterForm = function(){
			//console.log($scope.registration);
			$http({
				method: 'POST',
				url: 'index.php/register/registerUser',
				data: $scope.registration,
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				
			}).success(function(data){
					console.log(data);
					console.log('Form successfully submitted to the server');
					$scope.message = data;
				})
			.error(function(data){
				//console.log(data);
				$scope.registerFailed = "Your account could be created. Please try again";
			})
		}
		})
	// FUNCTIONALITY TO CHECK IF REFERER EMAIL IS A REGISTERED USER
// 	app.directive('ngUnique', ['$http', function ($http) {
//   return {
//     require: 'ngModel',
//     link: function (scope, elem, attrs, ctrl) {
//       elem.on('blur', function (evt) {
//         scope.$apply(function () {
//           $http({
//             method: 'POST',
//             url: $scope.siteURL + 'index.php/register/checkRefEmailExist',
//             data: {
//               username:elem.val(),
//               dbField:attrs.ngUnique
//             }
//           }).success(function(data, status, headers, config) {
//             ctrl.$setValidity('unique', data.status);
//           });
//         });
//       }
//     }
//   }
// ]);