<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	function __construct(){
		parent::__construct();
		
	}

	public function index()
	{
		$this->load->view('users_view/SignUpLoginView');
	}

	public function loadEmailConfirmationSentMsg(){
		$this->load->view('users_view/email_confirmation_view_message');
	}
	public function loadSingleLoginView(){
		// Please load the single login view where verified email users can proceed with login
	}
	public function registerUser(){
		print_r($_POST());
		die();
		
	}

	public function validate_email($email_code){
		$email_code = trim($email_code);
		$validated = $this->user->validate_email($email_code);

		if ($validated === true) {
			$this->load->view('users_view/validated_email_login_view');
		}else{
			// this should never happen
			echo "Error activating your email! please contact" . $this->config->item('admin_email');
		}
	}
	// checking if the referer email address exist in the database
	public function checkRefEmailExist(){
		$request = $this->input->post('refEmail');
		$this->load->model('user');
		$result = $this->users->checkRefererEmail($request);
		if ($result == true) {
			// echo json_encode(array('success'=>true, 'message'=>'referer email address exist'));
			echo "<p class='has-success text-success bg-success'> Email Available </p> ";
		}else{
			echo "<p class='has-error text-danger bg-danger'> Referer email must be a registered FUC user</p>";
		}
	}



}
