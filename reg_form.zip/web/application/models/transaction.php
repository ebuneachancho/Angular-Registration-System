<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class transaction extends MY_Model
{    
    const DB_TABLE = 'transactions';
                        
    public $transaction_date;    
    public $date_recorded;    
    public $amount;
    public $notes;   
    public $debit_account_id;    
    public $credit_account_id;
    public $transaction_type_id;
}

 
 

