<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class income_redistribution_setting extends MY_Model
{    
    const DB_TABLE = 'income_redistribution_settings';
                        
    public $level;    
    public $level_head_cash_out_percentage;       
    public $level_head_instanteneous_investment_percentage;
    public $level_head_menthor_cash_out_percentage;    
    public $level_head_menthor_instanteneous_investment_percentage;       
    public $level_head_menthor_monthly_investment_percentage;
}

 
 

