<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class transaction_type extends MY_Model
{    
    const DB_TABLE = 'transaction_types';
                        
    public $transaction_name;    
    public $description;    
    public $debit_account_id;
    public $credit_account_id;
}

 
 

