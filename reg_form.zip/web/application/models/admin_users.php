<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class admin_user extends MY_Model
{    
    const DB_TABLE = 'admin_users';
                        
    public $username;    
    public $password;       
    public $full_name;
}

 
 

