<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class user extends MY_Model
{    
    const DB_TABLE = 'users';
                                                       
    public $email;                                                
    public $full_name;                                            
    public $referrer_user_id;                                     
    public $gender           ;                                    
    public $town              ;                                   
    public $country            ;                                  
    public $password            ;                                 
    public $withdrawal_account_id;                                
    public $investment_account_id ;                               
    public $revenue_account_id     ;                              
    public $investment_history_account_id ;                       
    public $cash_withdrawal_history_accounts_id   ;               
    public $monthly_investment_account_id           ;             
    public $monthly_investment_redistribution_history_account_id ;
    public $level1_head_user_id                                  ;
    public $is_activated                                         ;


    public function saveUser($request){
        // Working code
        $query = $this->db->insert('users', array('full_name'=>$request['fullName'],
                        'email'=>$request['email'],'referrer_user_id'=>$request['refEmail'],
                        'password'=>$request['password'], 'gender'=>$request['gender'],
                        'town'=>$request['town'], 'country'=>$request['country'], 
                        'is_activated'=> 0, 'withdrawal_account_id' => 1, 'investment_account_id'=> 1,
                        'revenue_account_id' => 1, 'investment_history_account_id' => 1, 
                        'cash_withdrawal_history_accounts_id' => 1, 'monthly_investment_account_id' => 1,
                        'monthly_investment_redistribution_history_account_id'=> 1, 
                        'level1_head_user_id' => 1));

        // $query = $this->db->insert('users', $request);
       

        if ($this->db->affected_rows() === 1) {
           $sessionArray = array('fullName' => $request['fullName'], 
                                'email'=>$request['email'], 'refEmail'=>$request['refEmail']);
           $this->session->set_session($sessionArray);
           $this->send_validation_email();
            return $request['email'];
        }else{
            return false;
        }
    }

   public function send_validation_email(){
        $this->load->library('email');
        $email = $this->session->userdata('email');
        $fullName = $this->session->userdata('fullName');
        $email_code = md5($email);
        // Please make sure to add the logo of FUC in the confirmation email
        $this->email->set_mailtype('html');
        $this->email->from($this->config->item('fuc_email'), 'FUC');
        $this->email->to('ebuneachancho@gmail.com'); //$email
        $this->email->subject('Please activate your account at FUC');
        $message = '<!DOCTYPE html><html>
                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                    <head></head><body>';

        $message .= '<h3> Dear' . $fullName . '</h3>';
        $message .= '<p> Thanks for registering on Financial Upgrade Community! Please <strong>
                    <a href="' . base_url() . 'register/validate_email/' . $email_code . '/' . '">
                    click here </a></strong> to activate your account. After you have activate your account, 
                    you be able to log into FUC and start doing business </p>';

        $message .= '<p> Thank you! </p>';
        $message .= '<p> The team at FUC </p>';
        $message .= '<body></html>';

        $this->email->message($message);
        $this->email->send();
   }

   private function activate_account($email_code){
        $sql = 'UPDATE users SET is_activated = 1 WHERE md5(email) = "'.$email_code.'"';
        $this->db->query($sql);
        if ($this->db->affected_rows() == 1) {
            return true;
        }else{
            // make sure this never happends
            echo "Error when activating your account. please contact" . $this->config->item('admin_email');
            return false;
        }
   }
 
    public function checkRefererEmail($request){
        $this->db->where('referrer_user_id', $request);
        $query = $this->db->get('users');
        if ($query->num_rows() > 0) {
            return true;
        }else{
            return false;
        }
    }
    //activate user account
    function validate_email($email_code)
    {
        $this->db->where('md5(email)', $email_code);
        $result = $this->activate_account($email_code);
        if ($result === true) {
            return true;
        }else{
            return false;
        }
    }
}

 
 

