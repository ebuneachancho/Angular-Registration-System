<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class permission_group_permission extends MY_Model
{    
    const DB_TABLE = 'permission_group_permissions';
                        
    public $permission_id;    
    public $permission_group_id;
}

 
 

