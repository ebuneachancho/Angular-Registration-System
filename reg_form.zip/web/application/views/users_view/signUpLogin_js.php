<script>




	// $scope.siteURL = "<?php echo base_url();?>";
	// $scope.submitRegisterForm = function(){
	// 	$scope.post($scope.registerURL, {'fullName: $scope.fullName', 'email: $scope.email', 
	// 	'password: $scope.password', 'country: $scope.country', 'gender: $scope.gender',
	// 	 'town: $scope.town',  'refererEmail: $scope.refererEmail'})
	// 	.success(function(data){
	// 		console.log("Registration successfully");
	// 	}).error(function(data){
	// 		$scope.siteURL = '<?php echo base_url();?>';
	// 		redirect()
	// 	});
	// };
});





</script>