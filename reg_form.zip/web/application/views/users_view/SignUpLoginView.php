<!DOCTYPE html>
<html lang="en" ng-app="signupLoginApp">
<head>

	<title>Form Registration - Signup Login Form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<link rel="shortcut icon" href="<?php echo base_url('');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/css/bootstrap.min.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/css/animate.css');?>">
	<!-- Including my own css -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/css/main.css');?>">
	<!-- Font Awesome -->
	 
	<!-- Including jquery library -->
	<script src="<?php echo base_url('resources/js/jquery-2.1.4.min.js');?>">
	</script>
	<!-- Including bootstrap js library -->
	 <script src="<?php echo base_url('resources/js/bootstrap.min.js');?>">
	 </script>
	<script src="<?php echo base_url('resources/js/jquery-ui.js'); ?>"></script>
	<script src="<?php echo base_url('resources/js/jarallax.js');?>"></script>

	<!-- Including angularJs library -->
	<script src=""></script>
	<!-- <script src="bower_components/angular-auto-validate/dist/jcs-auto-validate.min.js"></script> -->
	
	<!-- INCLUDING ANGULAR CDN -->
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.6/angular.min.js"></script>

	<!-- INCLUSING MY ANGULARJS WORKING FILE  -->
	<script src="<?php echo base_url('resources/js/app.js');?>"></script>

</head>
<body style="background-image: url('resources/images/bg-02.jpg')">



<!-- Login and Registration form for users -->
<?php if (isset($successfullRegistered)): ?>
	<h2 class="alert alert-success text-success animated bounce"><?php echo $successfullRegistered;?></h2>
<?php endif ?>
<div class="container">
<h2 class="text-center text-danger bg-danger animated bounce">{{registerFailed}}</h2>
<h2 class="text-center text-success bg-success animated bounce">{{registerFailed}}</h2>
	<h1 class="text-center text-default" style="font-size:40px;">FUC User Registration{{1+1}}</h1>
	<div class="row">
		<!-- Login form begins here -->
		<div ng-controller="signUpController">
			<div class="col-xs-12 col-sm-5 col-lg-5 col-sm-offset-1 col-lg-offset-1" id="login">
				<h2 class="text-center"><strong style="color:#fff">REGISTER FORM</strong></h2>
				<form method="post" role="form" name="registerForm" ng-submit="submitRegisterForm()">
					<div class="form-group">
						<i class="fa fa-user-o" aria-hidden="true"></i>
						<input type="text" 
								class="form-control" 
								name="fullName" 
								ng-model="registration.fullName"
								required="required"
								title="This field cannot be empty. Please enter a valid Name" 
								placeholder="Your full name" />
							<span ng-show="registerForm.fullName.$touched && registerForm.fullName.$invalid" class="text-danger bg-danger">
								Full name must contain the right format
							</span>
					</div>
					<div class="form-group">
						<input type="email" 
								class="form-control" 
								name="email" 
								ng-model="registration.email"
								required="required" 
								placeholder="Your email address..."/>
							<span ng-show="registerForm.email.$touched && registerForm.email.$invalid " class="text-danger bg-danger">
								Email is invalid
							</span>
					</div>
					<div class="form-group">
						<input type="password"
								class="form-control" 
								name="password" 
								ng-minlength="5" 
								ng-model="registration.password"
								pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$" 
								title="Password should have atleast one upper case letter and a symbol" 
								placeholder="Enter Password..."/>
							<span ng-show="registerForm.password.$touched && registerForm.password.$invalid" class="text-danger bg-danger">
								Password must have atleast one uppercase and a sysmbol
							</span>
						
					</div>
					<div class="form-group">
						<select name="country" 
								class="form-control niceSelection" 
								ng-model="registration.country" 
								placeholder="your country" style="color: #666">
							<?php

							$countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

							?>
							<?php foreach ($countries as $country): ?>
								<?php echo "<option value='$country'>$country</option>"; ?>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group">
						<label class="radio-inline input-lg">
							<input type="radio" name="gender" value="Male" ng-model="registration.gender"><span style="color: #fff">Male</span>
						</label>
						<label class="radio-inline input-lg">
							<input type="radio" name="gender" value="Female" ng-model="registration.gender"><span style="color: #fff">Female</span>
						</label>
						<label class="radio-inline input-lg">
							<input type="radio" name="gender" value="Other" ng-model="registration.gender"><span style="color: #fff">Other</span>
						</label>
					</div>
					<div class="form-group">
						<input type="text" 
								name="town" 
								class="form-control" 
								ng-model="registration.town"
								pattern="^[a-z\d\.]{5,}$"
								title="Town names should not contain slashes" 
								placeholder="Enter the name of your town" 
								required="required">
					</div>
					<div class="form-group">
						<input type="email" 
								name="refererEmail" 
								id="refererEmail" 
								class="form-control" 
								ng-model="registration.refEmail"
								title="Email address not valid. please enter a valid email address" 
								placeholder="Enter email of referer"
								ng-unique="tableDB.userDBField">
							<span ng-show='registerForm.refererEmail.$error.unique'>
						   		Username already exists.
						    </span>
						    <span id="emailExist"></span>
					</div>
					<div class="form-group">
						<input type="submit" name="submit" ng-disabled="registerForm.$invalid || registerForm.$pristine" class="form-control btn btn-danger">
					</div><br>
				</form><br>
			</div>
		</div>
		<!-- End of login section -->

		<!-- signup form begins here -->
		<div class="col-xs-12 col-sm-4 col-lg-4 col-sm-offset-1 col-lg-offset-1" id="signup">
			<h2 class="text-center"><strong style="color:#fff">LOGIN FORM</strong></h2>
			<form method="post" action="" role="form">
				<div class="form-group">
					<input  type="email" 
							class="form-control" 
							name="loginEmail" 
							placeholder="Your email" required="required"/>
				</div>
				<div class="form-group">
					<input  type="password"
							name="loginPassword" 
							class="form-control" 
							placeholder="Your password" required="required"/>
				</div>
				<div class="checkbox">
				  	<h4 style="color:#fff" class="col-sm-7">
				  		<label><input type="checkbox" value="">Stay logged in</label>
				  	</h4>
				  	<h5 class="col-sm-5"><a href="<?php echo base_url('index.php/Users/usersDashboardController');?>">forgot password?</a></h5>
				</div>
				<div class="form-group">
					<input type="submit" 
							name="submit" 
							class="form-control btn btn-danger">
				</div><br>
			</form>
		</div>
	</div>
</div>

