<?php $this->load->view('partialViews/header');?>

<!-- End of primary header -->

Email confirmation message has been sent to your email. please click on the link in the email inother  to complete the regidtration process.